"""Local-only map/camera dashboard and operator supervision heartbeat."""
import json
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlsplit
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile,DurabilityPolicy,ReliabilityPolicy,qos_profile_sensor_data
from rclpy.time import Time
from std_msgs.msg import String,Empty
from std_srvs.srv import SetBool
from sensor_msgs.msg import Image
from nav_msgs.msg import OccupancyGrid,Path
from tf2_ros import Buffer,TransformListener
from .cameras import CameraFrames

PAGE=r'''<!doctype html><html><head><meta charset="utf-8"><title>Robot mapping</title>
<meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font:16px system-ui;background:#14202c;color:#eef;margin:24px}button{padding:14px;margin:8px;font-size:18px}canvas,img{max-width:100%;background:#778}pre{white-space:pre-wrap}section{display:flex;gap:20px;flex-wrap:wrap}article{flex:1 1 320px;min-width:0}img{width:100%}img[hidden]{display:none}.camera-state{color:#ffcf70}.camera-state.live{color:#9ee5b0}</style></head>
<body><h1>Explore and map</h1><p>Keep this page connected while moving. Closing it stops the drive.</p>
<button id="start">Start exploration</button><button id="stop">STOP</button><pre id="status">Connecting…</pre>
<p id="stopReason" role="status"></p>
<h2>Live motor and sensor readings</h2>
<p id="sensorFreshness">Waiting for telemetry</p>
<table style="width:100%;text-align:left"><thead><tr><th>Motor</th><th>Current (A)</th><th>Voltage (V)</th><th>Power (W)</th><th>Encoder count</th><th>Counts/s</th><th>PWM (%)</th><th>Current sensor</th></tr></thead>
<tbody><tr><td>1</td><td id="m1current">—</td><td id="m1voltage">—</td><td id="m1power">—</td><td id="m1count">—</td><td id="m1rate">—</td><td id="m1duty">—</td><td id="m1sensor">Waiting</td></tr>
<tr><td>2</td><td id="m2current">—</td><td id="m2voltage">—</td><td id="m2power">—</td><td id="m2count">—</td><td id="m2rate">—</td><td id="m2duty">—</td><td id="m2sensor">Waiting</td></tr></tbody></table>
<p id="shuntNote"></p><p id="steeringSummary"></p><pre id="sensorSummary"></pre>
<details><summary>Raw encoder and board telemetry</summary><pre id="telemetry"></pre></details><section><article><h2>Map and committed path</h2><canvas id="map"></canvas></article>
<article><h2>Front camera</h2><p id="frontStatus" class="camera-state" role="status">Waiting for front camera</p><img id="camera" alt="Front camera live view" hidden></article>
<article><h2>Rear camera</h2><p id="rearStatus" class="camera-state" role="status">Waiting for rear camera</p><img id="rearCamera" alt="Rear camera live view" hidden><label><input id="mirrorRear" type="checkbox"> Mirror rear view</label><p>Rear video is for viewing. Reverse clearance uses LiDAR.</p></article></section>
<script>
const token=new URLSearchParams(location.hash.slice(1)).get('token')||'';
const headers={'X-Control-Token':token};let busy=false;
const number=(v,digits=2)=>typeof v==='number'&&Number.isFinite(v)?v.toFixed(digits):'—';
function renderSensors(s){const drive=s.drive||{},data=drive.sensors||{},age=s.drive_age_s;const fresh=data.fresh===true&&typeof age==='number'&&age<=1.5;document.getElementById('sensorFreshness').textContent=fresh?'Live board telemetry · age '+number(data.age_s+age)+' s':'Telemetry unavailable or stale';for(let i=1;i<=2;i++){const motor=(data.motors||[]).find(m=>m.motor===i)||{};for(const [key,field,digits] of [['current','current_a',3],['voltage','voltage_v',2],['power','power_w',2],['count','count',0],['rate','counts_per_s',0],['duty','duty_pct',1]])document.getElementById('m'+i+key).textContent=fresh?number(motor[field],digits):'—';document.getElementById('m'+i+'sensor').textContent=fresh?(motor.current_status||'unavailable'):'stale';}document.getElementById('shuntNote').textContent='Current conversion uses '+number(data.ina_shunt_ohms,3)+' ohm shunts; match ina_shunt_ohms in calibration to your boards.';document.getElementById('steeringSummary').textContent='Steering: 1000–2000 µs · straight 1500 µs · front/rear target '+(fresh?(drive.steering_pulses||[]).join(' / '):'—');const f=fresh?(drive.fields||{}):{},ages=drive.sensor_ages||{},coverage=drive.rear_coverage||{};document.getElementById('sensorSummary').textContent='Heading / roll / pitch: '+(f.H??'—')+' / '+(f.R??'—')+' / '+(f.P??'—')+' degrees\nIMU valid: '+(f.VALID??'—')+' · calibration: '+(f.CAL??'—')+'\nLiDAR / IMU / EKF age: '+['lidar','imu','ekf'].map(k=>typeof age==='number'&&typeof ages[k]==='number'?number(ages[k]+age)+' s':'—').join(' / ')+'\nFront / rear video age: '+['front','rear'].map(k=>number(s.cameras?.[k]?.age_s)+' s').join(' / ')+'\nSpeed: '+(fresh?number(drive.speed,3):'—')+' m/s · odometry encoder: '+(drive.encoder_index??'—')+'\nRear coverage: '+(coverage.known_bins??'—')+'/'+(coverage.required_bins??'—')+' sectors';const exploration=s.exploration||{};document.getElementById('stopReason').textContent=exploration.enabled?'Exploring · '+(exploration.reason||''):'Stopped: '+(exploration.reason||drive.reason||'Waiting')+(exploration.last_stop?' · last stop: '+exploration.last_stop.reason:'');}
async function call(path,body,timeoutMs=4000){let r=await fetch(path,{method:body?'POST':'GET',headers:{...headers,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(timeoutMs)});if(!r.ok)throw Error(await r.text());return r;}
async function action(enable){try{let r=await call('/action',{enable});document.querySelector('#status').textContent=JSON.stringify(await r.json(),null,2)}catch(e){document.querySelector('#status').textContent=e.message}}
let hbBusy=false;setInterval(async()=>{if(hbBusy)return;hbBusy=true;try{await fetch('/heartbeat',{headers,signal:AbortSignal.timeout(700)})}catch(e){}finally{hbBusy=false}},250);
document.querySelector('#start').onclick=()=>action(true);document.querySelector('#stop').onclick=()=>action(false);
document.addEventListener('keydown',e=>{if(e.code==='Space'||e.key==='Escape'){e.preventDefault();action(false)}});
setInterval(async()=>{if(busy)return;busy=true;try{let s=await(await call('/state')).json();renderSensors(s);document.querySelector('#status').textContent=JSON.stringify({drive:{state:s.drive.state,reason:s.drive.reason,health:s.drive.health,speed:s.drive.speed,requested_speed:s.drive.requested_speed,applied_duty:s.drive.applied_duty,obstacle:s.drive.obstacle,rear_coverage:s.drive.rear_coverage},exploration:s.exploration,fusion:s.fusion,motor_ceiling:s.drive.max_duty_pct,wheel_confidence:s.drive.wheel_confidence},null,2);document.querySelector('#telemetry').textContent=JSON.stringify(s.drive.fields||{},null,2);const m=s.map;if(m){const c=document.querySelector('#map');c.width=m.width;c.height=m.height;const ctx=c.getContext('2d');let img=await createImageBitmap(await(await call('/map.png')).blob());ctx.drawImage(img,0,0);let xy=p=>[(p[0]-m.x)/m.resolution,m.height-(p[1]-m.y)/m.resolution];if(s.path.length){ctx.strokeStyle='#08f';ctx.lineWidth=2;ctx.beginPath();s.path.forEach((p,i)=>{let q=xy(p);i?ctx.lineTo(...q):ctx.moveTo(...q)});ctx.stroke()}if(s.robot){let p=xy(s.robot);ctx.fillStyle='#f22';ctx.beginPath();ctx.arc(...p,4,0,7);ctx.fill()}}}catch(e){renderSensors({});document.querySelector('#status').textContent=e.message}finally{busy=false}},500);
const views={front:{id:'camera',status:'frontStatus',path:'/camera.jpg'},rear:{id:'rearCamera',status:'rearStatus',path:'/camera/rear.jpg'}};
for(const view of Object.values(views)){view.busy=false;view.url=null;view.goodAt=0;}
function clearCamera(view,message){const el=document.getElementById(view.id);el.hidden=true;el.removeAttribute('src');if(view.url)URL.revokeObjectURL(view.url);view.url=null;view.goodAt=0;const status=document.getElementById(view.status);status.textContent=message;status.classList.remove('live');}
async function camera(name){const view=views[name];if(view.busy||document.hidden)return;view.busy=true;try{const r=await call(view.path,undefined,800);const blob=await r.blob();if(document.hidden)return;const url=URL.createObjectURL(blob);const el=document.getElementById(view.id);el.src=url;el.hidden=false;if(view.url)URL.revokeObjectURL(view.url);view.url=url;view.goodAt=performance.now();const status=document.getElementById(view.status);status.textContent='Live';status.classList.add('live');}catch(e){clearCamera(view,'No fresh '+name+' camera image');}finally{view.busy=false;}}
for(const [name,view] of Object.entries(views))document.getElementById(view.id).onerror=()=>clearCamera(view,'Unable to display '+name+' camera image');
document.getElementById('mirrorRear').onchange=e=>{document.getElementById('rearCamera').style.transform=e.target.checked?'scaleX(-1)':'';};
setInterval(()=>{for(const [name,view] of Object.entries(views)){if(view.goodAt&&performance.now()-view.goodAt>1200)clearCamera(view,'Stale '+name+' camera image');camera(name);}},350);
document.addEventListener('visibilitychange',()=>{if(document.hidden)for(const view of Object.values(views))clearCamera(view,'Camera paused');});
</script></body></html>'''


class Dashboard(Node):
    def __init__(self):
        super().__init__('exploration_dashboard')
        import cv2
        import numpy as np
        from cv_bridge import CvBridge
        self.cv2=cv2;self.np=np;self.cv=CvBridge();self.drive={};self.exploration={};self.fusion={};self.drive_received=None
        self.map_info=None;self.png=b'';self.path=[];self.robot=None
        self.cameras=CameraFrames();self.camera_encoded={'front':0.,'rear':0.}
        self.declare_parameter('front_camera_topic','/camera/image_raw')
        self.declare_parameter('rear_camera_topic','/camera/rear/image_raw')
        self.heartbeat=self.create_publisher(Empty,'operator_heartbeat',10)
        self.explore_client=self.create_client(SetBool,'explore/enable')
        self.drive_client=self.create_client(SetBool,'drive/enable')
        self.tf=Buffer();self.listener=TransformListener(self.tf,self)
        self.create_subscription(String,'drive/status',self.drive_cb,10)
        self.create_subscription(String,'fusion/status',lambda m:setattr(self,'fusion',json.loads(m.data)),10)
        self.create_subscription(String,'explore/status',lambda m:setattr(self,'exploration',json.loads(m.data)),10)
        qos=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL,reliability=ReliabilityPolicy.RELIABLE)
        self.create_subscription(OccupancyGrid,'map',self.map_cb,qos)
        self.create_subscription(Path,'plan',lambda m:setattr(self,'path',[[p.pose.position.x,p.pose.position.y] for p in m.poses]),10)
        for name in ('front','rear'):
            self.create_subscription(Image,self.get_parameter(name+'_camera_topic').value,
                lambda msg,name=name:self.camera_cb(msg,name),qos_profile_sensor_data)
        self.create_timer(.5,self.pose_cb)

    def drive_cb(self,msg):
        self.drive=json.loads(msg.data);self.drive_received=time.monotonic()

    def map_cb(self,msg):
        if msg.info.width*msg.info.height>4000000:return
        a=self.np.array(msg.data,dtype=self.np.int16).reshape(msg.info.height,msg.info.width)
        image=self.np.where(a<0,128,self.np.where(a>=50,0,255)).astype(self.np.uint8)
        ok,png=self.cv2.imencode('.png',self.np.flipud(image))
        if ok:
            self.png=png.tobytes();self.map_info=dict(width=msg.info.width,height=msg.info.height,
                resolution=msg.info.resolution,x=msg.info.origin.position.x,y=msg.info.origin.position.y)

    def camera_cb(self,msg,name='front'):
        if time.monotonic()-self.camera_encoded[name]<.3:return
        try:
            stamp=msg.header.stamp.sec+msg.header.stamp.nanosec/1e9
            now=self.get_clock().now().nanoseconds/1e9
            if stamp<=0 or not -.1<=now-stamp<=1.:return
            image=self.cv.imgmsg_to_cv2(msg,'bgr8')
            ok,jpeg=self.cv2.imencode('.jpg',image,[self.cv2.IMWRITE_JPEG_QUALITY,65])
            if ok:
                self.cameras.update(name,jpeg.tobytes(),stamp,self.get_clock().now().nanoseconds/1e9)
                self.camera_encoded[name]=time.monotonic()
        except Exception:pass

    def pose_cb(self):
        try:
            t=self.tf.lookup_transform('map','base_link',Time()).transform.translation
            self.robot=[t.x,t.y]
        except Exception:self.robot=None

    def service(self,client,value):
        if not client.service_is_ready():raise RuntimeError('Service unavailable')
        req=SetBool.Request();req.data=value;f=client.call_async(req)
        end=time.monotonic()+4
        while not f.done() and time.monotonic()<end:time.sleep(.02)
        if not f.done():raise RuntimeError('Service timed out')
        res=f.result();return dict(success=res.success,message=res.message)


def main():
    rclpy.init();node=Dashboard();token=secrets.token_urlsafe(32)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def reply(self,status,body,kind='application/json'):
            if not isinstance(body,bytes):body=(json.dumps(body) if kind=='application/json' else body).encode()
            self.send_response(status);self.send_header('Content-Type',kind)
            self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)));self.end_headers()
            self.wfile.write(body)
        def authorized(self):return secrets.compare_digest(self.headers.get('X-Control-Token',''),token)
        def do_GET(self):
            path=urlsplit(self.path).path
            if path=='/':self.reply(200,PAGE,'text/html');return
            if not self.authorized():self.reply(403,{'error':'Open the complete token link'});return
            if path=='/heartbeat':
                node.heartbeat.publish(Empty())
                self.reply(200,{'ok':True})
            elif path=='/state':
                self.reply(200,dict(fusion=getattr(node,'fusion',{}),drive=node.drive,exploration=node.exploration,map=node.map_info,path=node.path,robot=node.robot,cameras=node.cameras.status(),drive_age_s=(node.cameras.clock()-node.drive_received if getattr(node,'drive_received',None) is not None else None)))
            elif path=='/map.png' and node.png:self.reply(200,node.png,'image/png')
            elif path in ('/camera.jpg','/camera/rear.jpg'):
                jpeg=node.cameras.get('rear' if path=='/camera/rear.jpg' else 'front')
                if jpeg:self.reply(200,jpeg,'image/jpeg')
                else:self.reply(503,{'error':'No fresh camera image'})
            else:self.reply(404,{'error':'No data yet'})
        def do_POST(self):
            if not self.authorized():self.reply(403,{'error':'Unauthorized'});return
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<1000:raise ValueError('Invalid request size')
                body=json.loads(self.rfile.read(size))
                if self.path!='/action' or type(body.get('enable')) is not bool:raise ValueError('Invalid action')
                result=node.service(node.explore_client,body['enable'])
                if not body['enable']:node.service(node.drive_client,False)
                self.reply(200,result)
            except Exception as e:self.reply(400,{'error':str(e)})
    server=ThreadingHTTPServer(('127.0.0.1',8005),Handler)
    worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
    print('SLAM-EXPLORER-0.13.1 http://127.0.0.1:8005/#token='+token,flush=True)
    try:rclpy.spin(node)
    except KeyboardInterrupt:pass
    finally:server.shutdown();node.destroy_node();rclpy.shutdown()
