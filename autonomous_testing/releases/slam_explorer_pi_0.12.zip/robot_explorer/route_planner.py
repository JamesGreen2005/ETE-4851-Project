"""Rolling-horizon viewpoint planning for a counter-steered vehicle."""
import math


def viewpoint_goals(data,width,height,resolution,origin,pose,wheelbase,max_steer,margin=.12,visits=()):
    """Sample feasible forward arcs; require observed footprint clearance.

    Unknown cells contribute information gain around a viewpoint, but never
    authorize driving through them. Nav2 performs the final path validation.
    """
    if resolution<=0 or len(data)!=width*height or wheelbase<=0:
        return [],dict(error='Invalid map or geometry',valid_viewpoints=0)
    ox,oy=origin;rx,ry,yaw=pose
    def value(x,y):
        gx,gy=math.floor((x-ox)/resolution),math.floor((y-oy)/resolution)
        return data[gy*width+gx] if 0<=gx<width and 0<=gy<height else -1
    # Include the square's corners, rather than testing only the goal center.
    body_radius=math.hypot(.1524,.1524)
    radius=body_radius+margin
    step=resolution*.7
    offsets=[(ix*step,iy*step) for ix in range(-math.ceil(radius/step),math.ceil(radius/step)+1)
             for iy in range(-math.ceil(radius/step),math.ceil(radius/step)+1)
             if math.hypot(ix*step,iy*step)<=radius+resolution*.5]
    cache={}
    def clear(x,y,padding=margin):
        key=(round(x,6),round(y,6),round(padding,6))
        if key not in cache:cache[key]=all(0<=value(x+dx,y+dy)<50 for dx,dy in offsets
            if math.hypot(dx,dy)<=body_radius+padding+resolution*.5)
        return cache[key]
    result=[];diagnostics=dict(candidates=0,rejected_unknown_or_obstacle=0)
    full_start_clear=clear(rx,ry)
    if not full_start_clear and not clear(rx,ry,0.):
        return [],dict(error='Current body footprint intersects unknown or occupied map cells',valid_viewpoints=0)
    for direction in (1.,-1.):
        for turn in (0.,-.25,.25,-.5,.5,-.75,.75,-1.,1.):
            curvature=2*math.tan(turn*max_steer)/wheelbase
            for distance in (.25,.35,.5,.7,1.,1.4,1.8):
                diagnostics['candidates']+=1
                points=[];valid=True
                for j in range(1,math.ceil(distance/.05)+1):
                    s=direction*min(distance,j*.05)
                    bx=s if abs(curvature)<1e-9 else math.sin(curvature*s)/curvature
                    by=0. if abs(curvature)<1e-9 else (1-math.cos(curvature*s))/curvature
                    x=rx+math.cos(yaw)*bx-math.sin(yaw)*by
                    y=ry+math.sin(yaw)*bx+math.cos(yaw)*by
                    # A chassis already inside an inflation margin must be able
                    # to move away. Never shrink its physical body; restore full
                    # padding within 0.4 m and check every intervening pose.
                    padding=margin if full_start_clear else margin*min(1.,abs(s)/.4)
                    if not clear(x,y,padding):valid=False;break
                    points.append((x,y))
                if not valid:
                    diagnostics['rejected_unknown_or_obstacle']+=1;continue
                x,y=points[-1]
                if math.hypot(x-rx,y-ry)<.2:continue
                # Score information near the viewpoint, independent of whether a
                # frontier cluster directly touches the inflated reachable region.
                unknown=sum(value(x+.7*math.cos(a*math.pi/12),y+.7*math.sin(a*math.pi/12))<0 for a in range(24))
                revisits=sum(math.exp(-((x-v[0])**2+(y-v[1])**2)/.16) for v in visits)
                score=1.+unknown*.18+min(distance,1.4)*1.3-abs(turn)*.2-min(revisits,8.)*.5-(.2 if direction<0 else 0.)
                result.append(dict(x=x,y=y,yaw=yaw+curvature*direction*distance,score=score,size=unknown,
                                   source='steering_arc',distance=distance,turn=turn,direction=int(direction)))
    result.sort(key=lambda g:g['score'],reverse=True)
    # Keep distinct endpoints so retries explore different routes.
    distinct=[]
    for goal in result:
        if not any(math.hypot(goal['x']-g['x'],goal['y']-g['y'])<.18 for g in distinct):distinct.append(goal)
    diagnostics['valid_viewpoints']=len(distinct)
    return distinct,diagnostics
